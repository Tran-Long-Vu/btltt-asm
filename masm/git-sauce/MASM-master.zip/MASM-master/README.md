# MASM Code Files

All these codes using pure masm with masm32sdk and WinAPI.

## Call API
- Echo.asm
- HelloWorld1.asm
- x64 samples

## Load API from PEB (Tested on Win 10)
- HelloWorld1.asm
- EchoLoadAPImanual.asm
- Reverse.asm (x64)

## Using masm32sdk
- file with 'x86' postfix in name.